package pro.boram.ex;

public class RSPGame {
	private String u;
	private String comStr;
	private int result;
	private String user1; //유저가 낸 것을 다시뽑기위해.

	public String getU() {
		return u;
	}

	public RSPGame(String u) {
		this.u = u;
	}

	public void gameResult() {
		int user;
		comStr = "";
		int com = (int) (Math.random() * 2);

		if (u.equals("s")) {
			user = 0;
			user1 = "가위";
		} else if (u.equals("r")) {
			user = 1;
			user1 = "바위";
		} else {
			user = 2;
			user1 = "보";
		}

		if (com == 0) {
			comStr = "가위";
		} else if (com == 1) {
			comStr = "바위";
		} else {
			comStr = "보";
		}
		if (user >= 0 && user <= 2) {
			if ((com == 0 && user == 1) || (com == 1 && user == 2) || (com == 2 && user == 0)) {
				result = 1;
			} else if (com == user) {
				result = 2;
			} else {
				result = 3;
			}

		}

	}
	public String getComStr() {
		return comStr;
	}

	public int getResult() {
		return result;
	}

	public String getUser1() {
		return user1;
	}
}
