package pro.boram.ex;

public class Lotto {
	private int[] numbers;

	public Lotto() {
		this.numbers = new int[6];
	}

	public void makeNum() {
		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = (int) (Math.random() * 45 + 1);
			for (int j = 0; j < i; j++) {
				if (numbers[i] == numbers[j])
					i--;
			}
		}
	}
	public int getNumber(int n) {
		return this.numbers[n-1];
	}

}
